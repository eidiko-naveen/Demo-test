"""Database infrastructure and persistence models."""
