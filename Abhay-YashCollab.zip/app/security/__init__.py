"""Authentication and authorization foundations."""
