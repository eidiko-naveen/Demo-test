"""Versionable prompt templates."""
