"""Provider-neutral agent tools."""
